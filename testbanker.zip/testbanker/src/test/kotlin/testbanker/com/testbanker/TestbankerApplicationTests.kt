package testbanker.com.testbanker

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class TestbankerApplicationTests {

	@Test
	fun contextLoads() {
	}

}
